# Source / methodology notes

- Parsed PSARC 1.4 archive and extracted 8,004 `dc1` files.
- Parsed DC00 state-script structures using public `t2r-dc-disasm` layout knowledge.
- DC VM instructions are fixed 8-byte records; call targets and call args were reconstructed with a linear register simulation.
- State transitions are recovered from `go` calls by matching the first call argument against state SIDs in the same state script.
- 64-bit StringIDs are FNV-1a 64-bit.
- Known native function hashes are mapped from dconstruct's public `sid_addresses.tsv`.
- Unknown hashes remain explicit rather than guessed.
- Branch-sensitive call order is best-effort; this is not a perfect high-level decompiler.
