# TLOU2R Interaction Architecture — Reverse-Engineering Handoff

## Scope

Source analyzed: the user-provided TLOU2 Remastered PC 1.6 `bin.psarc`.

- PSARC `dc1` files extracted: **8,004**
- Interaction-focused files initially classified: **749**
- Core systems deeply traced in this handoff: drawer, cabinet, door, investigate object, examine, safe, lock HUD, workbench, ladder, Naughty Dog interaction testbed, and selected level-specific interactables.
- This package contains analysis/metadata only; it does not redistribute the game binaries.

## High-level architecture

```text
LEVEL / ACTOR / LEVEL-SPECIFIC SCRIPT
                |
                v
         INTERACTION DEF
     (prompt/input presentation)
                |
                v
        INTERACTABLE SYSTEM
                |
                v
          STATE SCRIPT
        /      |       \
 player align animation object state
       |        |          |
       +--------+----------+
                |
          events / camera
          /      |       \
        UI      audio    inventory
                          / save state
```

The shipped scripts strongly support a component-style architecture: reusable interaction definitions + reusable state scripts + reusable animation modules, with level-specific scripts composing them.

## 1. Drawer system

State graph recovered:

```text
wait-interact
  -> spawned-open
  -> complete
  -> interact

interact
  -> scavenge-move-to

scavenge-move-to
  -> scavenge-enter
  -> melee-abort

scavenge-enter
  -> scavenge-pickup
  -> scavenge-exit
  -> melee-abort

scavenge-pickup
  -> scavenge-exit
  -> melee-abort

scavenge-exit
  -> wait-pickup
  -> scavenge-pickup
  -> scavenge-early-exit
  -> melee-abort

scavenge-early-exit
  -> wait-pickup
  -> melee-abort

spawned-open -> wait-pickup
wait-pickup -> complete
melee-abort -> wait-interact / wait-pickup
```

Key engine references:
- `interactable-disable`
- object/locator position and alignment
- `joypad-disable-all-commands-except`
- `holding-no-weapon?`
- `animate_`
- `get-animation-phase`
- `attach`
- `send-event` / `broadcast-event`
- object-spawn checks

Interpretation:
- `scavenge-move-to` = alignment/input-lock stage.
- `scavenge-enter` = opening + synchronization stage.
- `scavenge-pickup` = hand/object attachment + animation-phase synchronization.
- Inventory modification is not owned directly by this drawer state machine; pickup/inventory is a separate reusable pipeline.

The drawer binary contains animation families selected by stance/tension and geometry, including crouched/relaxed/tense variants at multiple handle heights (roughly 30–120 cm). It also logs entry angle, top/width edges, handle height, weapon holstering and nav-blocker behavior. This is a geometry-aware fitting system, not one canned animation.

## 2. Investigate + Examine = the "pick up a book and inspect/read it" stack

### `ss-investigate-object`

```text
setup -> wait-interact
wait-interact -> quick-grab OR enter-and-investigate
quick-grab -> complete
enter-and-investigate -> investigate-exit / attacked-out / complete
attacked-out -> wait-interact / complete
early-cancel -> wait-interact
investigate-exit -> wait-interact / complete
```

This layer references:
- interact-definition override
- camera activation
- player/object locator positioning
- object attachment and visibility
- collectible/treasure checks
- animation
- broadcast/send events
- telemetry/logging
- player identity/state checks
- cancellation and attacked-out paths

### `ss-examine`

```text
wait-interact
  -> examine-enter-cut
  -> examine-enter-blend

examine-enter-cut -> examine-enter-2 -> examine-idle
examine-enter-blend -> examine-idle

examine-idle
  -> read
  -> fridge
  -> examine-exit-cut
  -> examine-exit-blend

read -> examine-idle
fridge -> examine-idle
examine-exit-* -> done OR wait-interact
done -> complete
```

This is the strongest match for close-up inspect/read behavior. Declarations include named parameters such as `enter-anim`, `idle-anim`, `exit-anim`, an `ap-ref`, `disabled`, and `used`.

The player animation module separately contains investigate front/back idle and swap transitions, which supports the idea that object manipulation/front-back viewing is handled at the animation/input layer while `ss-examine` owns the interaction state.

## 3. Safe + lock HUD

World safe and UI minigame are separate systems.

### `ss-tumbler-safe`

```text
setup -> wait-interact / already-complete / complete
wait-interact -> move-to
move-to -> play-idle
play-idle -> input-number
check-inventory -> input-number / early-exit
input-number -> open / fail / early-exit / attacked-out
open -> complete
fail -> play-idle / early-exit / another internal branch
early-exit -> wait-interact
attacked-out -> wait-interact
already-complete -> complete
```

References include camera control, animation, player input, inventory/collectible checks, animation phase, world events, and telemetry.

Confirmed event-style symbol: `opened-safe`; failure side includes `failed-safe`.

### `ss-hud2-lock-minigame`

```text
wait-for-data -> setup
setup -> input-code / finish-combo
input-code -> finish-combo / investigate
finish-combo -> success / fail
fail -> input-code
investigate -> input-code
```

This layer builds/manipulates GUI widgets and receives combo/input data. It is cleanly separated from the safe actor's physical/camera state.

## 4. Workbench

Workbench is effectively a mini interactive application inside gameplay.

Recovered states include:
- initialize
- wait-for-player
- unavailable
- trap-mode
- workbench-enter
- workbench-idle
- workbench-idle-weapon-on-table
- workbench-idle-hand-in-bag
- apply-upgrade
- inspect-weapon
- pullout/put-away weapon
- disassemble weapon
- assemble weapon
- workbench-exit

It references:
- interaction-definition overrides
- pickup-scan exclusion
- object alignment
- camera/fades
- menu page stack
- input disabling
- weapon ID/state
- animation phases
- object attachment
- mesh visibility toggles
- upgrade conditions
- events/facts/logging
- player identity (Ellie/Abby)

This is a strong template for building entirely new "interaction stations" using existing engine functions.

## 5. Interaction UI definition layer

`gui2-game.bin` exposes **111 named `interact-*` definitions**. Examples include:
- openable drawer/cabinet/object
- safe tumbler
- workbench variants
- directional door variants
- door needs power
- pushable puzzles
- rope attach/climb
- squeeze-through
- hold/mash prompts
- right/left-stick rotation
- conversations
- contextual look
- controller-shake platform variants

`interactable.bin` separately contains the prompt assets/commands:
- `gen:interact`
- `gen:look-at`
- `menu:action`
- `menu:back`
- `menu:inspect`
- Triangle/hold icons
- investigate icon
- collectible/pickup widgets
- PC-specific button/pickup widgets

So UI presentation is not hardwired into each drawer/safe/etc script.

## 6. Level-specific composition

Examples from Patrol:
- library globe: `task-check -> wait-interact -> animate -> complete`; uses camera + animation.
- joke book: same small level-script shell, with descriptive text "Ellie picks up a jokebook and reads from it."
- heater: same shell with an interaction-specific result.
- Scar intro map: `wait-interact -> examine -> wait-interact`.

This shows a level designer can place a bespoke narrative interaction while reusing generic interaction/examine systems.

## 7. Animation engine boundary

The module registry contains dedicated modules for:
- player door
- investigate/look-at/journal
- ladder/climb/edge-climb
- push object
- squeeze-through
- rope/free-rope/drag-rope/wall-rope
- motion matching
- state processing
- animation warps

The interaction scripts call `animate_`, query animation phase, align locators, and wait on events. They orchestrate animation; they do not implement the underlying animation engine.

## 8. Audio boundary

The module registry contains dedicated common-object audio packages, including:
- doors and multiple door materials/handles
- cabinet metal/wood/fridge/locker
- drawer metal/wood and drawer/cabinet handles
- safe
- keypad
- generator
- rope materials
- physics books and paper
- many other physical materials

This is strong evidence that interaction scripts trigger/synchronize higher-level events/animations while material/object-specific audio lives in dedicated audio modules. For drawers, the traced state machine does not appear to own the actual material SFX implementation.

## 9. Native AI boundary

The shipped module registry exposes dedicated AI systems such as:
- `ai/search-params`
- `ai/cover-params`
- `ai/infected-params`
- `ai/combat-params`
- AI archetypes/action packs
- encounter perception controller/settings
- infected perception stats
- clicker hearing test scripts
- directed hearing prototypes
- knowledge-spread/search prototypes

This supports the current boundary: DC state scripts can configure/orchestrate AI-facing behavior, but core perception/navigation/decision code remains native engine territory.

## 10. Resource/persistence boundary

The script ecosystem contains:
- `player-inventory`
- `script-funcs-inventory`
- facts and `fact-set`
- SVAR usage / `set-svar-value`
- dynamic checkpoint managers
- level-set modules
- part modules and streamed level parts
- numerous checkpoint/inventory-control scripts

The lockbox example already proves persistent state can be stored as an SVAR. Interaction states also broadcast events and set facts. Asset streaming itself appears to remain beneath the script layer.

## Current confidence

High confidence:
- state topology
- module separation
- interaction UI definition layer
- geometry-aware drawer/cabinet fitting
- investigate/examine split
- safe/world vs HUD minigame split
- workbench subsystem architecture
- audio package separation

Medium confidence:
- exact meaning of every anonymous declaration/SID
- exact branch condition on every transition
- exact native implementation beneath unresolved function hashes

The call tracer is a best-effort linear VM based on the public DC opcode implementation; it is excellent for function/reference discovery and transition recovery, but it is not yet a perfect typed source reconstruction.
