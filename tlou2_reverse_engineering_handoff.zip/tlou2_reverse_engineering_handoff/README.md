# TLOU2R reverse-engineering handoff

Analysis generated from the user's own TLOU2R 1.6 `bin.psarc`.

Files:
- `INTERACTION_ARCHITECTURE.md` — findings and system map
- `core_interaction_call_map.json` — state-by-state calls and transitions
- `core_state_summary.csv` — compact state/subsystem table
- `interaction_definitions.csv` — 111 UI interaction definitions
- `SOURCE_NOTES.md` — methodology/limitations

No game binaries are included.
